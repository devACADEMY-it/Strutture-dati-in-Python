#
# Strutture dati in Python 
# I set, esempio riepilogativo: controllo schedine
#
# Disponibile su devACADEMY.it
#

schedine=[]
schedine.append({21,12,56,78,34,90})
schedine.append({21,78,3,15,34,56})
schedine.append({4,16,7,45,58,9})
schedine.append({21,78,3,45,58,9})

vincente={21,45,58,11,82,90}

for s in schedine:
	numeri_giusti=vincente.intersection(s)
	if len(numeri_giusti)>1:
		print("All'interno di ", end="")
		print(s, end=" ci sono "+str(len(numeri_giusti))+" numeri giusti: ")
		print(numeri_giusti)
		print()