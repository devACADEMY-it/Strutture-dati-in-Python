#
# Strutture dati in Python 
# I dizionari, esempio riepilogativo
#
# Disponibile su devACADEMY.it
#

risultati_partite=['Torino-Milan 3-2', 
'Sampdoria-Lazio 1-1', 
'Sampdoria-Torino 2-0',
'Milan-Lazio 1-0',
'Sampdoria-Milan 0-0',
'Lazio-Torino 0-0'
]

totale={}

def somma_punti(squadra, punti):
   if squadra in totale:
     totale[squadra]+=punti
   else:
     totale[squadra]=punti

def analizza_partita(partita):
   squadre, punteggio=partita.split()
   squadra_casa, squadra_ospite=squadre.split('-')
   goal_casa, goal_ospite=punteggio.split('-')
   if goal_casa==goal_ospite:
     somma_punti(squadra_casa, 1)
     somma_punti(squadra_ospite, 1)
   elif goal_casa>goal_ospite:
     somma_punti(squadra_casa, 3)
   else:
     somma_punti(squadra_ospite, 3)
	 
for p in risultati_partite:
   analizza_partita(p)

for x in sorted(totale.items(), key=lambda i: i[1], reverse=True):
   print('{} {}'.format(x[0], x[1]))