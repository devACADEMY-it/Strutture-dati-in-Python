#
# Strutture dati in Python 
# Strutture di base e creazione di utenti
#
# Disponibile su devACADEMY.it
#

from collections import namedtuple, deque

socialnetwork=dict()

Post=namedtuple('Post', 'author date message')
User=namedtuple('User', 'username posts followers following')

def createUser(username):
  if username not in socialnetwork:
     newuser=User(username=username, posts=deque(), followers=set(), following=set())
     socialnetwork[newuser.username]=newuser
     return newuser
	 

createUser('pippo71')
createUser('chanelle')
createUser('luna')

print(socialnetwork)