#
# Strutture dati in Python 
# Gestione dei post
#
# Disponibile su devACADEMY.it
#

from collections import namedtuple, deque

socialnetwork=dict()

Post=namedtuple('Post', 'author date message')
User=namedtuple('User', 'username posts followers following')

def createUser(username):
  if username not in socialnetwork:
     newuser=User(username=username, posts=deque(), followers=set(), following=set())
     socialnetwork[newuser.username]=newuser
     return newuser
	 
def publish_post(username, date, message):
  if username in socialnetwork:
     user=socialnetwork[username]
     new_post=Post(username, date, message)
     user.posts.appendleft(new_post)
	 
	 

createUser('pippo71')
createUser('chanelle')
createUser('luna')

publish_post('pippo71', '2019-03-01', 'Oggi pranzo fuori')
publish_post('pippo71', '2019-03-06', 'Gallina vecchia fa buon brodo')
publish_post('pippo71', '2019-03-17', 'Mi hanno licenziato :(')
publish_post('pippo71', '2019-03-28', 'Sono felice!!')

publish_post('chanelle', '2019-02-15', 'Amo il mio ragazzo')
publish_post('chanelle', '2019-03-12', 'Oggi brutto tempo!!')

publish_post('luna', '2019-04-01', 'Oggi attenti agli scherzi!!')

print(socialnetwork)