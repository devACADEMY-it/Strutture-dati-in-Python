#
# Strutture dati in Python 
# Following e follower
#
# Disponibile su devACADEMY.it
#

from collections import namedtuple, deque

socialnetwork=dict()

Post=namedtuple('Post', 'author date message')
User=namedtuple('User', 'username posts followers following')

def createUser(username):
  if username not in socialnetwork:
     newuser=User(username=username, posts=deque(), followers=set(), following=set())
     socialnetwork[newuser.username]=newuser
     return newuser
	 
def publish_post(username, date, message):
  if username in socialnetwork:
     user=socialnetwork[username]
     new_post=Post(username, date, message)
     user.posts.appendleft(new_post)
	 
def set_following(followed, follower):
  if followed!=follower:
    followed_user=socialnetwork[followed]
    follower_user=socialnetwork[follower]
    followed_user.followers.add(follower)
    follower_user.following.add(followed)
	
def get_homepage_posts(username):
  if username in socialnetwork:
    user=socialnetwork[username]
    posts=[]
    for f in user.following:
       posts+=socialnetwork[f].posts
    return sorted(posts, key=lambda post: post.date, reverse=True)

createUser('pippo71')
createUser('chanelle')
createUser('luna')

publish_post('pippo71', '2019-03-01', 'Oggi pranzo fuori')
publish_post('pippo71', '2019-03-06', 'Gallina vecchia fa buon brodo')
publish_post('pippo71', '2019-03-17', 'Mi hanno licenziato :(')
publish_post('pippo71', '2019-03-28', 'Sono felice!!')

publish_post('chanelle', '2019-02-15', 'Amo il mio ragazzo')
publish_post('chanelle', '2019-03-12', 'Oggi brutto tempo!!')

publish_post('luna', '2019-04-01', 'Oggi attenti agli scherzi!!')

set_following('pippo71', 'chanelle')
set_following('pippo71', 'luna')
set_following('chanelle', 'luna')

print(socialnetwork)